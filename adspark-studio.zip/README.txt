ADSPARK STUDIO - WEBSITE
========================
FILES: index.html (home), contact.html, style.css, script.js, images/ (your 16 portfolio images, unchanged)

OPEN IT: double-click index.html. No tools or installs needed. (Fonts load from Google Fonts when online; the site falls back to system fonts offline.)

EDIT IT:
- Text: open the .html files in any text editor (Notepad, VS Code).
- Colors: the 7 palette colors are at the top of style.css (--c0 to --c6).
- Add a portfolio image: put it in images/ and copy one <figure>...</figure> line in index.html.

CONTACT FORM (needs 2 minutes of setup - it will NOT send until you do this):
A website cannot send email by itself, so use a free form service:
1. Go to https://formspree.io and sign up with aleeza4ez@gmail.com.
2. Create a new form. Copy its URL (looks like https://formspree.io/f/xxxxxxxx).
3. Open script.js, find  const FORM_ENDPOINT = "";  and paste the URL between the quotes.
4. Upload the site, submit a test message, and confirm the email arrives (confirm Formspree's verification email first).
Until then the form shows an honest "not set up" message and sends nothing. The phone, email and WhatsApp buttons work without setup.
No passwords or secret keys are stored in this site.

PUBLISH IT: upload the whole folder to Netlify (drag-and-drop at app.netlify.com/drop), GitHub Pages, or any web host. Keep the folder structure as is.
