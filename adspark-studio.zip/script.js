/* AdSpark Studio - script.js */
/* ===== CONTACT FORM SETUP (see README.txt) =====
   Paste your Formspree form URL here, e.g. https://formspree.io/f/abcdwxyz */
const FORM_ENDPOINT = "";
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];

/* Mouse glow with smooth trailing (disabled on touch devices) */
(function () {
  const g = $("#glow");
  if (!g || matchMedia("(hover: none), (pointer: coarse)").matches) { g && g.remove(); return; }
  let tx = innerWidth / 2, ty = innerHeight / 2, x = tx, y = ty;
  addEventListener("mousemove", e => { tx = e.clientX; ty = e.clientY; g.classList.add("on"); });
  document.addEventListener("mouseleave", () => g.classList.remove("on"));
  (function loop() { x += (tx - x) * .14; y += (ty - y) * .14; g.style.transform = `translate3d(${x}px,${y}px,0)`; requestAnimationFrame(loop); })();
})();

/* Nav: solid on scroll, mobile menu, page transitions */
const nav = $(".nav");
const onScroll = () => nav.classList.toggle("solid", scrollY > 40);
addEventListener("scroll", onScroll, { passive: true }); onScroll();
$(".burger").addEventListener("click", () => $(".menu").classList.toggle("open"));
$$(".menu a").forEach(a => a.addEventListener("click", () => $(".menu").classList.remove("open")));
$$("a[href$='.html']").forEach(a => a.addEventListener("click", e => {
  if (e.metaKey || e.ctrlKey || a.target) return;
  e.preventDefault(); document.body.classList.add("leaving"); setTimeout(() => location.href = a.href, 230);
}));
addEventListener("pageshow", () => document.body.classList.remove("leaving"));

/* Scroll reveal */
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: .12 });
$$(".rv").forEach(el => io.observe(el));

/* Hero: split headline into animated words, 3D tilt on floating products */
const h1 = $("h1[data-split]");
if (h1) h1.innerHTML = h1.textContent.trim().split(/\s+/).map((w, i) => `<span class="w"><i style="--i:${i}">${w}</i></span>`).join(" ");
const stage = $(".stage");
if (stage && matchMedia("(hover: hover)").matches) {
  stage.addEventListener("mousemove", e => {
    const r = stage.getBoundingClientRect(), dx = (e.clientX - r.left) / r.width - .5, dy = (e.clientY - r.top) / r.height - .5;
    $$(".float", stage).forEach((f, i) => f.style.transform = `rotateY(${dx * 14}deg) rotateX(${-dy * 14}deg) translate(${dx * (i + 1) * 12}px,${dy * (i + 1) * 12}px)`);
  });
  stage.addEventListener("mouseleave", () => $$(".float", stage).forEach(f => f.style.transform = ""));
}

/* Portfolio lightbox (shows the full, uncropped image) */
const lb = $(".lb");
if (lb) {
  $$(".gallery img").forEach(img => img.parentElement.addEventListener("click", () => { $("img", lb).src = img.src; $("img", lb).alt = img.alt; lb.classList.add("open"); }));
  lb.addEventListener("click", () => lb.classList.remove("open"));
  addEventListener("keydown", e => e.key === "Escape" && lb.classList.remove("open"));
}

/* Contact form: validation + real submission. Never reports success unless the server confirms. */
const form = $("#contact-form");
if (form) {
  const status = $("#status"), btn = $("button[type=submit]", form);
  const show = (msg, ok) => { status.textContent = msg; status.className = "show"; status.setAttribute("role", ok ? "status" : "alert"); };
  const rules = { name: v => v.trim().length >= 2, email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()), service: v => !!v, details: v => v.trim().length >= 10 };
  const check = el => { const ok = !rules[el.name] || rules[el.name](el.value); el.classList.toggle("bad", !ok); const m = el.nextElementSibling; if (m && m.classList.contains("err")) m.classList.toggle("show", !ok); return ok; };
  $$("input,select,textarea", form).forEach(el => el.addEventListener("blur", () => check(el)));
  form.addEventListener("submit", async e => {
    e.preventDefault();
    if (!$$("input,select,textarea", form).map(check).every(Boolean)) return show("Please fix the highlighted fields and try again.", false);
    if (!FORM_ENDPOINT) return show("Email delivery is not set up yet, so nothing was sent. Add your form endpoint in script.js (see README.txt), or contact us directly by phone, email or WhatsApp.", false);
    btn.disabled = true; btn.firstChild.textContent = "Sending...";
    try {
      const res = await fetch(FORM_ENDPOINT, { method: "POST", headers: { Accept: "application/json" }, body: new FormData(form) });
      if (!res.ok) throw new Error("HTTP " + res.status);
      form.reset(); show("Thank you. Your message was delivered and we will reply soon.", true);
    } catch (err) { show("Your message could not be sent. Please try again, or email aleeza4ez@gmail.com directly.", false); }
    btn.disabled = false; btn.firstChild.textContent = "Send Message";
  });
}
